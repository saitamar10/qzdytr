<?php if ( ! defined( 'ABSPATH' )  ) { die; } // Cannot access directly.

//
// Set a unique slug-like ID
//
$prefix = '_prefix_taxonomy_options';

//
// Create taxonomy options
//
CSF::createTaxonomyOptions( $prefix, array(
  'taxonomy' => 'category',
  'data-type' => 'unserialie',
) );
//
// Create a section
//
CSF::createSection( $prefix, array(
  'fields' => array(
    //
    // A text field
    // 
      array(
      'id'    => '_zero-classification-cbl-kg',
      'type'  => 'switcher',
      'title' => 'kenar çubuğunu aç',
      'label' => 'Kenar çubuğunu açma ve kapatma',
        'subtitle' => 'yeşil açık',
       'default' => true,
    ),
    
    			array(
				'id'    => 'zero-header-classification-banner-imgurl',
				'type'  => 'upload',
				'title' => 'başlık afişi',

			),
			    array(
        'id'    => 'is_filter',
        'type'  => 'switcher',
        'title' => 'Bu sayfada gelişmiş filtrelemeyi devre dışı bırakın',
        'subtitle' => 'yeşil devre dışı',
        'default' => false,
    ),
    
  )
) );