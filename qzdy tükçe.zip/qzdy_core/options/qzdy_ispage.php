<?php // Control core classes for avoid errors
if( class_exists( 'CSF' ) ) {

  //
  // Set a unique slug-like ID
  $prefix = 'my_post_optionss0';

  //
  // Create a metabox
  CSF::createMetabox( $prefix, array(
    'title'     => 'Genişletilmiş işlev',
    'post_type' => 'page',
    'data_type'  => 'unserialize',
  ) );

  //
  // Create a section
  CSF::createSection( $prefix, array(
    'title'  => 'SEO ayarları',
    'fields' => array(

      //
      // A text field
            array(
        'id'    => 'qzdy_zdy_ym_key',
        'type'  => 'text',
        'title' => 'özel anahtar kelimeler',
      ),
            array(
        'id'    => 'qzdy_zdy_ym_des',
        'type'  => 'text',
        'title' => 'özel açıklama',
      ),

    )
  ) );

  //
  // Create a section
//   CSF::createSection( $prefix, array(
//     'title'  => 'Tab Title 2',
//     'fields' => array(

//       // A textarea field
//       array(
//         'id'    => 'opt-textarea',
//         'type'  => 'textarea',
//         'title' => 'Simple Textarea',
//       ),

//     )
//   ) );

}
