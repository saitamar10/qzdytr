<?php
    if( class_exists( 'CSF' ) ) {
    $tips_6_2 = '';
    $prefix = 'my_framework';
    CSF::createOptions( $prefix, array(
    'menu_title' => 'Qzdy tema ayarları',
    'menu_slug' => 'my-framework',
    ) );
// Q-Q交-流群：9173673-58
// 作者博客：https://www.aj0.cn/
    CSF::createSection( $prefix, array(
		'id'    => 'zero_x',
		'title' => 'Temel Ayarlar',
		'icon'  => 'fa fa-plus-circle',
		
	) );
	CSF::createSection( $prefix, array(
		'parent'      => 'zero_x',
		'title'  => 'Arka plan resmi ve diğerleri',
		'fields' => array(
      array(
        'type'    => 'subheading',
        'content' => 'Baş resmiyle ilgili ayarlar',
      ),
		    		    array(
      'id'    => 'zero-header-gbqzbjan',
      'type'  => 'switcher',
      'title' => 'baş dünya haritası',
      'label' => 'Varsayılan olarak, tüm sitenin başlığının arka plan görüntüsü etkindir.',
       'subtitle' => 'Gezinme çubuğunun arkasındaki resim',
       'default' => true,
    ),
		 array(
      'id'      => 'opt-index-banner-moxin',
      'type'    => 'radio',
      'title'   => 'Head modeli seçimi',
      'inline'  => 'opt-index-xbanner',
      'options' => array(
        'opt-index-dbanner' => 'Metin içeren büyük resim',
        'opt-index-xbanner' => 'Metinsiz küçük resim',
      ),
      'default' => 'opt-index-xbanner',
    ),
    		 array(
      'id'      => 'opt-index-header-color-box',
      'type'    => 'radio',
      'title'   => 'Gezinme çubuğu renk seçimi',
      'inline'  => 'opt-index-xbanner',
      'options' => array(
        'opt-index-header-color-box1' => 'Varsayılan sistem',
        'opt-index-header-color-box2' => 'beyaz efekt',
        'opt-index-header-color-box3' => 'buzlu cam efekti',
      ),
      'default' => 'opt-index-header-color-box1',
    ),
    			array(
				'id'    => 'zero-header-classification-banner-morenbanner',
				'type'  => 'upload',
				'title' => 'Metin içeren büyük resim',
                'default' =>  get_template_directory_uri().'/images/bg_pic.jpg',
			),
			array(
				'id'    => 'zero-footer-qzbj',
				'type'  => 'upload',
				'title' => 'Metin başlığı olmayan küçük resim',
				'default' =>  get_template_directory_uri().'/images/bg_pic.jpg',
			),
                array(
                    'id'    => 'opt-group-topping-datu-title',
                    'type'  => 'text',
                    'title' => 'metin içeren büyük resim yazısı',
                    'default' =>  'Başlık',
                ),                array(
                    'id'    => 'opt-group-topping-datu-futitle',
                    'type'  => 'text',
                    'title' => 'Metin altyazılı büyük resim',
                    'default' =>  'alt yazı',
                ),
      array(
        'type'    => 'subheading',
        'content' => 'Web sitesi arka plan resimleri ve özel efektler',
      ),
			array(
				'id'    => 'zero-body-background-image',
				'type'  => 'upload',
				'title' => 'Web Sitesi Arka Plan Resmi',
				 'subtitle' => 'Web sitesi genel arka plan resmi - boş varsayılanlar süt beyazı',
			),
		array(
      'id'    => 'zero-index-js-to-footer',
      'type'  => 'switcher',
      'title' => 'Arka plan efektlerini etkinleştir',
      'label' => 'Arka plan efektlerini etkinleştir',
       'subtitle' => 'Arka plan efektleri varsayılan olarak etkindir',
       'default' => true,
         ),
        		 array(
      'id'      => 'zero-index-texiao-box',
      'type'    => 'radio',
      'title'   => 'Düşen bir efekt seçin',
      'inline'  => 'opt-index-xbanner',
      'options' => array(
         'zero-index-texiao-guanbi' => 'Efektsiz',
        'zero-index-texiao-yinghua' => 'Kiraz çiçekleri',
        'zero-index-texiao-xuehua' => 'kar tanesi',
      ),
      'default' => 'zero-index-texiao-guanbi',
    ),
      array(
        'type'    => 'subheading',
        'content' => 'Arka planda oturum açma ile ilgili ayarlar',
      ),
			array(
				'id'    => 'zero-login-background-image',
				'type'  => 'upload',
				'title' => 'Web sitesi arka planı giriş arka plan resmi',
				 'subtitle' => 'Süt beyazı için boş varsayılanlar',

			),
			array(
				'id'    => 'zero-login-background-image-logo',
				'type'  => 'upload',
				'title' => 'Web sitesi arka plan giriş logosu',
			),
	)
	) );
    CSF::createSection( $prefix, array(
    'parent'      => 'zero_x',
    'title' => 'Temel Ayarlar',
    'fields' => array(
          array(
        'type'    => 'subheading',
        'content' => 'Ev Kategori Kategori Kimliğini Hariç Tut',
      ),
        	array(
			    'id'    => 'zero-qt-index-paichuid',
				'type'  => 'text',
				'title' => 'Ev Kategori Kategori Kimliğini Hariç Tut',
                'subtitle' => 'Bu kategorilerdeki makaleler ana sayfadaki en son makalelerde görüntülenmez ve birden fazla makale yarım genişlikte İngilizce virgülle ayrılır, örneğin：-1,-3,-12。',
			),
      array(
        'type'    => 'subheading',
        'content' => 'Ana Sayfa ve Kategori Makale Ayarları',
      ),
             	array(
				'id'    => 'qzdy-index-piece',
				'type'  => 'text',
				'title' => 'Ana Sayfa Makale Sayısı',
				'default' => '10',
			), 
    array(
      'id'          => 'opt-depend-visible-text',
      'type'        => 'text',
      'title'       => 'Sınıflandırılmış makalelerin sayısı, lütfen kenar çubuğu->ayarlar->okuma->blog sayfası görünümündeki konumu en fazla değiştirin',
      	'default' => 'Lütfen Kenar Çubuğu->Ayarlar->Okuma->En Çok Konum Değiştirmede Blog Sayfası Görüntüleme seçeneğine gidin.',
    ),
      array(
        'type'    => 'subheading',
        'content' => 'Sayfalandırma yükleme yöntemi',
      ),
    		 array(
      'id'      => 'rp-fanye-mode',
      'type'    => 'radio',
      'title'   => 'Sayfalandırma yükleme yöntemi',
      'inline'  => 'rp-fanye-modes',
      'options' => array(
        '1' => 'sayfalandırma yükleme',
        '2' => 'yenilemeden yükle',
      ),
      'default' => '1',
    ),
      array(
        'type'    => 'subheading',
        'content' => 'Mobil kenar çubuğu giriş modu',
      ),
			array(
      'id'    => 'zero-index-cbl-login',
      'type'  => 'switcher',
      'title' => 'Cep telefonunun kenar çubuğunda oturum açma durumunun etkinleştirilip etkinleştirilmediği',
       'default' => false,
    ),
      array(
        'type'    => 'subheading',
        'content' => 'Arka planda oturum açma şablonu',
      ),
        array(
      'id'      => 'opt-index-lgoin-muban',
      'type'    => 'radio',
      'title'   => 'Arka planda kayıt giriş sayfası şablonu',
      'inline'  => 'opt-sidebar-right',
      'options' => array(
        'opt-login-yi' => 'Şablon bir',
        'opt-login-er' => 'Şablon iki',
      ),
      'default' => 'opt-login-yi',
    ),
      array(
        'type'    => 'subheading',
        'content' => 'Site genelinde duyuru ayarları',
      ),
	array(
      'id'    => 'zero-index-gg-notice',
      'type'  => 'switcher',
      'title' => 'Açık duyuru',
       'default' => false,
    ),
	array(
      'id'    => 'zero-index-gg-zd-gb',
      'type'  => 'switcher',
      'title' => 'Otomatik olarak kapatılıp kapatılmayacağı',
       'default' => false,
    ),
	array(
				'id'    => 'qzdy-index-gg-notice-title',
				'type'  => 'text',
				'title' => 'Başlık',
				'default' => 'Tema güncelleme ipuçları',
			),
 array(
      'id'       => 'qzdy-index-gg-notice-content',
      'type'     => 'code_editor',
      'title'    => 'açılır içerik',
      'subtitle' => 'Yalnızca sayfa ilk kez açıldığında açılır',
      'default' => 'Tema githubta sürekli güncellenecek.',
    ),
    )
    ) );
    CSF::createSection( $prefix, array(
    'parent'      => 'zero_x',
    'title' => 'Arama Ayarı',
    'fields' => array(
			                array(
                  'id'    => 'zero-qt-index-sosuo-redian',
                  'type'     => 'code_editor',
                  'title'    => 'Arama sayfaları için sıcak düğme',
                  'subtitle' => 'Kendi html stillerinizi ekleyebilirsiniz',
                  'settings' => array(
                    'theme'  => 'shadowfox',
                     'mode'   => 'htmlmixed',
                  ),
                  'default' =>'<li><a href="#">Test</a></li><li><a href="#">Test</a></li><li><a href="#">Test</a></li>',
                ),
    )
    ) );
// Q-Q交-流群：9173673-58
// Field: 文章内页设置
CSF::createSection($prefix, array(
    'title'  => 'Kategori sayfası filtresi',
    'icon'   => 'fa fa-circle',
    'fields' => array(
        array(
            'id'      => 'is_filter_bar',
            'type'    => 'switcher',
            'title'   => 'Kategorinin iç sayfasında filtrelemeyi devre dışı bırak',
            'label'   => 'Tüm site için, tek tek kategorileri kapatmanız gerekiyorsa, lütfen tek tek özelleştirmek için kategori düzenleyiciye gidin.',
            'default' => true,
        ),
        array(
            'id'         => 'is_filter_item_cat',
            'type'       => 'switcher',
            'title'      => 'İç sayfalarda birinci düzey kategori filtrelemeyi etkinleştir',
            'label'      => '',
            'default'    => true,
            'dependency' => array('is_filter_bar', '==', 'false'),
        ),
        array(
            'id'          => 'archive_filter_cat_1',
            'type'        => 'select',
            'title'       => 'Birincil Ana Kategori Filtreleme Yapılandırması',
            'desc'        => 'Sıralama kuralları, ayarlanan sıraya dayalıdır.',
            'placeholder' => 'Kategori Seçin',
            'inline'      => true,
            'chosen'      => true,
            'multiple'    => true,
            'options'     => 'categories',
            'query_args'  => array(
                'orderby' => 'count',
                'order'   => 'DESC',
                'parent'  => 0,
            ),
            'dependency' => array('is_filter_item_cat', '==', 'true'),
        ),
        array(
            'id'         => 'is_filter_item_cat2',
            'type'       => 'switcher',
            'title'      => 'İkincil kategori filtrelemeyi etkinleştir',
            'label'      => 'Mevcut filtre kriterleri kategorisi altında ikincil bir kategori varsa, ikincil kategori otomatik olarak görüntülenecektir.',
            'default'    => true,
            'dependency' => array('is_filter_bar', '==', 'false'),
        ),
        array(
            'id'         => 'is_filter_item_cat3',
            'type'       => 'switcher',
            'title'      => 'Üç seviyeli sınıflandırma filtrelemeyi etkinleştir',
            'label'      => 'Geçerli filtre kriterleri kategorisi altındaki ikinci düzey kategoride üçüncü düzey bir kategori bulunur ve üçüncü düzey kategori otomatik olarak görüntülenir.',
            'default'    => true,
            'dependency' => array('is_filter_bar', '==', 'false'),
        ),
        array(
            'id'      => 'is_filter_item_cat_orderby',
            'type'    => 'radio',
            'title'   => 'Kategoriye göre sırala'.$tips_6_2,
            'inline'  => true,
            'options' => array(
                'id'    => 'Kategori ID',
                'name' => 'Kategori adı',
                'count' => 'makale sayısı',
            ),
            'default' => 'id',
        ),
        array(
            'id'         => 'is_filter_item_tags',
            'type'       => 'switcher',
            'title'      => 'İlgili etiket filtrelemeyi etkinleştir',
            'label'      => 'İlgili etiketler otomatik olarak görüntülenir',
            'default'    => true,
            'dependency' => array('is_filter_bar', '==', 'false'),
        ),
       array(
            'id'      => 'filter_item_tags_num',
            'type'    => 'text',
            'title'   => 'İlgili etiketler, gösterim sayısını filtreler',
            'default' => '10',
            'dependency' => array('is_filter_item_tags', '==', 'true'),
        ),
        // array(
        //     'id'      => 'is_custom_post_meta_opt',
        //     'type'    => 'switcher',
        //     'title'   => 'Gelişmiş Özel Makale Alanı Özellikleri',
        //     'desc'    => 'Esas olarak kaynakları filtrelemek ve rafine etmek için kullanılır, gelişmiş özel makale alanı özellikleri <b><font color="red">Her alan adında iki veya iki alan seçeneği olmalıdır, aksi takdirde bir hata bildirilir</font></b>',
        //     'default' => false,
        // ),
        // array(
        //     'id'         => 'custom_post_meta_opt',
        //     'type'       => 'group',
        //     'title'      => 'Özel Alan Ayarları',
        //     'max'        => '50',
        //     'fields'     => array(
        //         array(
        //             'id'      => 'meta_name',
        //             'type'    => 'text',
        //             'title'   => 'Alan adı',
        //             'default' => 'alan 1',
        //         ),
        //         array(
        //             'id'      => 'meta_ua',
        //             'type'    => 'text',
        //             'title'   => 'Alan İngilizce Kimliği',
        //             'default' => 'my_meta_1',
        //         ),
        //         array(
        //             'id'          => 'meta_category',
        //             'type'        => 'select',
        //             'title'       => 'Gelişmiş filtre özelliklerini yalnızca bu kategori altında göster',
        //             'placeholder' => 'Hepsini Göster ↓',
        //             'chosen'      => true,
        //             'multiple'    => true,
        //             'options'     => 'categories',
        //         ),
        //         array(
        //             'id'     => 'meta_opt',
        //             'type'   => 'group',
        //             'title'  => 'Alan seçenekleri',
        //             'fields' => array(
        //                 array(
        //                     'id'      => 'opt_name',
        //                     'type'    => 'text',
        //                     'title'   => 'Seçenek  adı',
        //                     'default' => 'Alan seçeneği 1',
        //                 ),
        //                 array(
        //                     'id'      => 'opt_ua',
        //                     'type'    => 'text',
        //                     'title'   => 'Seçenek İngilizce logosu',
        //                     'default' => 'opt_1',
        //                 ),
        //             ),
        //         ),
        //     ),
        //     'dependency' => array('is_custom_post_meta_opt', '==', 'true'),
        // ),
    ),
));
// 作者博客：https://www.aj0.cn/
      CSF::createSection( $prefix, array(
    'parent'      => 'zero_x',
    'title' => 'Ana Şablon Anahtarı',
    'fields' => array(
    array(
      'id'      => 'opt-index-buju',
      'type'    => 'image_select',
      'title'   => 'Ana Şablon Anahtarı',
      'inline'  => 'opt_img',
      'options' => array(
        'opt_blog' =>  get_template_directory_uri().'/images/qzdy_buju_1.svg',
        'opt_img' => get_template_directory_uri().'/images/qzdy_buju_2.svg',
      ),
      'default' => 'opt_blog',
    ),
    array(
      'id'      => 'opt-index-sidebar-position',
      'type'    => 'radio',
      'title'   => 'kenar çubuğu konumu',
      'inline'  => 'opt-sidebar-right',
      'options' => array(
        'opt-sidebar-left' => 'Sol',
        'opt-sidebar-right' => 'Sağ',
      ),
      'default' => 'opt-sidebar-right',
    ),
    
    )
    ) );
CSF::createSection( $prefix, array(
    'parent'      => 'zero_x',
    'title' => 'Ana sayfa en iyi makale',
    'fields' => array(
        		    array(
      'id'    => 'zero-index-zhidibng',
      'type'  => 'switcher',
      'title' => 'Ana sayfanın üst kısmını açın',
      'label' => 'Ana sayfanın üst kısmını açın',
       'subtitle' => 'Atlıkarınca Altında Dört Sabitlenmiş Makale',
       'default' => false,
    ),
                    array(
      'id'          => 'zero-index-topping-box',
      'type'        => 'select',
      'title'       => 'Sabitlenmesi gereken makaleleri ayarlayın',
      'chosen'      => true,
      'multiple'    => true,
      'sortable'    => true,
      'ajax'        => true,
      'options'     => 'posts',
      'placeholder' => 'Lütfen iki veya daha fazla karakter içeren makale başlığını arayınız.',
    ),
)
) );
CSF::createSection( $prefix, array(
    'parent'      => 'zero_x',
    'title' => 'Sağ alttaki kayan çubuk',
    'fields' => array(
array(
  'id'         => 'opt-checkbox-2',
  'type'       => 'checkbox',
  'title'      => 'Lütfen gerekli bileşenleri seçin',
  'options'    => array(
    'c-comment' => 'Yorum',
    'c-sousuo' => 'Ara',
    'c-mail' => 'Mail',
    'c-contribution' => 'Katkıda bulun',
    'c-full-screen' => 'Tam ekran',
    'c-tips' => 'Başa dönüş',
  ),
  'default'    => array(  'c-email', 'c-tips' ,'c-full-screen', 'c-sousuo', 'c-comment')
),

array(
    'id'      => 'txt-c-email',
    'type'    => 'text',
    'title'   => 'Mail',
    'default' => 'info@mail.com',
),
array(
    'id'      => 'txt-c-tougao',
    'type'    => 'text',
    'title'   => 'Katkı bağlantısı',
    'default' => 'https://ismetceber.com.tr/',
),
)
) );
CSF::createSection( $prefix, array(
    'parent'      => 'zero_x',
    'title' => 'Döngü ayarları',
    'fields' => array(
        array(
      'id'    => 'zero-index-bannerkg',
      'type'  => 'switcher',
      'title' => 'atlıkarınca aç',
       'subtitle' => 'Dönen yeri varsayılan olarak kapatın',
       'default' => false,
        ),
        array(
      'id'    => 'zero-index-bannerkg-wzgn',
      'type'  => 'switcher',
      'title' => 'Resim metnini kapat',
       'subtitle' => 'Resim metni varsayılan olarak etkindir',
       'default' => true,
        ),
        array(
            'id'     => 'opt-group-topping-zhiding',
            'type'   => 'group',
            'title'  => 'Ana sayfa slayt gösterisi ayarları',
            'max' => 4,
            'fields' => array(
                array(
                    'id'    => 'opt-group-topping-title',
                    'type'  => 'text',
                    'title' => 'Başlık',
                ),
               array(
		    	    'id'    => 'zero-banner-topping-img',
		    	    'type'  => 'upload',
			       'title' => 'haritanın adresi',
			         'default' => '',
		    	),
                array(
                     'id'    => 'opt-text-topping-url',
                     'type'  => 'text',
                     'title' => 'Linki',
                ),
               )
            ),
    )
    ) );
CSF::createSection( $prefix, array(
		'title'  => 'Arka plan optimizasyonu (önerilir)',
		'icon'  => 'fas fa-wrench',
		'description' => 'Açık değilse, açmanız şiddetle tavsiye edilir, devre dışı bırakmak için eklentiler kurmayın! etkinleştir devre dışı bırak',
		'fields' => array(
array(
      'id'    => 'zero-ht-jyxbxgj',
      'type'  => 'checkbox',
      'title' => 'Arka plan widgetı',
      'subtitle' => 'Devre dışı bırakıldıktan sonra önemli hız artışı',
      'label' => 'Yeni gadgetları devre dışı bırak.',
      'default' => true,
    ),
    array(
      'id'    => 'zero-ht-jyxbbjq',
      'type'  => 'checkbox',
      'title' => 'Arka plan yeni sürüm düzenleyici',
      'subtitle' => 'Devre dışı bırakıldıktan sonra önemli hız artışı',
      'label' => 'Yeni düzenleyiciyi devre dışı bırak.',
      'default' => true,
    ),
    array(
      'id'    => 'zero-ht-htkqzdttx',
      'type'  => 'checkbox',
      'title' => 'Özel avatar özelliğini etkinleştir',
      'subtitle' => 'Açtıktan sonra, kenar çubuğunda: Kullanıcı > Profil > Altta resim yükle',
      'label' => 'Özel avatar özelliğini etkinleştir',
      'default' => true,
    ),
    array(
      'id'    => 'zero-wzl-category',
      'type'  => 'checkbox',
      'title' => 'Kategori bağlantılarını devre dışı bırak /category',
    //   'subtitle' => 'Açtıktan sonra, kenar çubuğunda: Kullanıcı > Profil > Altta resim yükle',
      'label' => 'Kategori bağlantılarını devre dışı bırak /category',
      'default' => false,
    ),
        array(
      'id'    => 'zero-bjq-zengqiang',
      'type'  => 'checkbox',
      'title' => 'Düzenleyici geliştirmeleri',
      'subtitle' => 'Kötü yapılandırmaya sahip bazı sunucular, açıldıklarında xu micro kartını hissedebilir.',
      'label' => 'Varsayılan olarak açık',
      'default' => true,
    ),
	)
	) );
               CSF::createSection( $prefix, array(
    'title' => 'Logo ayarları',
    'icon'  => 'far fa-image',
    'fields' => array(
			array(
				'id'    => 'zero-header-favicon',
				'type'  => 'upload',
				'title' => 'favicon图标',
			     'subtitle' => 'Tarayıcı pencerelerinde küçük simgeler',
				'default' =>  get_template_directory_uri().'/favicon.ico',
				'subtitle' => 'ico simgesi .ico son eki küçük resminin teknik özelliklere göre ayarlanması önerilir.',
			),
 array(
      'type'    => 'notice',
      'style'   => 'info',
      'content' => 'Web sitesi LOGO ayarları',
    ),
			array(
				'id'    => 'zero-footer-logo',
				'type'  => 'upload',
				'title' => 'Logo resmi adresi 200x60',
				'default' =>  get_template_directory_uri().'/images/logo.png',
			),
			array(
			    'id'    => 'zero-qt-wzlogo',
				'type'  => 'text',
				'title' => 'metin logosu',
                'default' => 'echo \'başlık\';',
			),
						        array(
      'id'    => 'zero-ht-logokg',
      'type'  => 'checkbox',
      'title' => 'Metin logosunu etkinleştir',
      'subtitle' => 'Metin logolarını otomatik olarak etkinleştir seçeneğini işaretleyin   Devre dışı bırakarak Görüntü logolarını otomatik olarak etkinleştirilir.',
      'label' => 'Metin logosunu etkinleştir',
      'default' => true,
    ),
			
    )
    ) );
// Q-Q交-流群：9173673-58
// 作者博客：https://www.aj0.cn/
    CSF::createSection( $prefix, array(
    'title' => 'Kişisel ayarlar',
    'icon'  => 'far fa-address-card',
    'fields' => array(
        	array(
				'id'    => 'zero-footer-txurl',
				'type'  => 'upload',
				'title' => 'avatar adresi',
				'default' =>  get_template_directory_uri().'/images/tx.jpg',
			),

            array(
				'id'    => 'zero-footer-txxnc',
				'type'  => 'text',
				'title' => 'Nick',
				'default' => 'isim Soyisim',
			),
			array(
				'id'    => 'zero-footer-txqm',
				'type'  => 'text',
				'title' => 'işaret',
				'default' => 'işte imza',
			),
			array(
				'id'    => 'zero-footer-email',
				'type'  => 'text',
				'title' => 'Mail',
				'subtitle' => 'Boş bırakırsanız, makalenin sonunda bileşene ilişkin iletişim bilgileri',
				'default' => 'info@mail.com',
			),

			array(
				'id'    => 'zero-header-wzyxrq',
				'type'  => 'text',
				'title' => 'Web sitesi çalışma tarihi formatı: yıl-ay-gün',
				'subtitle' => 'Lütfen biçime tam olarak uygun olarak girin, örneğin: 2021-01-02',
				'default' => '2021-01-02',
			),
            array(
                'id' => 'zero-footer-txbjt',
                'type' => 'upload',
                'title' => 'Avatar Arka Plan Resmi',
                'default' =>  get_template_directory_uri().'/images/txbj.jpg',
                ),
            array(
                'id' => 'zero-personal-huangguan',
                'type' => 'upload',
                'title' => 'Mobil avatarın yanındaki taç',
                'default' =>  get_template_directory_uri().'/images/qzdy_huangguan.svg',
                ),
 array(
      'type'    => 'notice',
      'style'   => 'info',
      'content' => 'Kişisel bilgilerin altındaki simge düğmesi',
    ),
     array(
      'id'    => 'widget-icon-box-kg',
      'type'  => 'switcher',
      'title' => 'tüm düğmelerin kapatılıp kapatılmayacağı',
      'label' => '',
       'default' => false,
    ),
    array(
      'id'       => 'qzdy-widget-icon',
      'type'     => 'group',
      'title'    => 'Kişisel bilgilerin altındaki simge düğmesi',
      'subtitle' => 'Görünüm Gadgetı Profili Ekleme',
      'min'      => 1,
      'max'      => 5,
      'fields'   => array(
        array(
          'id'    => 'widget-icon-title',
          'type'  => 'text',
          'title' => 'Başlık',
        ),
          array(
      'id'    => 'widget-icon-ico',
      'type'  => 'icon',
      'title' => 'Simge seçimi',
    ),
        array(
      'id'      => 'widget-icon-background',
      'type'    => 'color',
      'title'   => 'arka plan rengi',
      'default' => '#3498db',
    ),
            array(
      'id'      => 'widget-icon-color',
      'type'    => 'color',
      'title'   => 'Simge rengi',
      'default' => '#fff',
    ),
        array(
          'id'    => 'widget-icon-href',
          'type'  => 'text',
          'title' => 'Simge Link',
        ),
      ),
      'default' => array(
        array(
            'widget-icon-title'=>'QQ',
          'widget-icon-ico'     => 'fa fa-qq',
          'widget-icon-background' => '#020202',
          'widget-icon-color' => '#fff',
        ),
        array(
            'widget-icon-title'=>'Mail',
          'widget-icon-ico'     => 'fa fa-envelope-o',
          'widget-icon-background' => '#020202',
          'widget-icon-color' => '#fff',
        ),
      )
    ),
           array(
      'id'    => 'widget-icon-dashang',
      'type'  => 'switcher',
      'title' => 'ipucu düğmesi',
      'label' => '',
       'default' => false,
    ),
                array(
                  'id'       => 'widget-icon-dashang-html',
                  'type'     => 'code_editor',
                  'title'    => 'Resim içeriği satır içi kontrol ile yazılabilir',
                  'subtitle' => 'Kendi html stillerinizi ekleyebilirsiniz',
                  'settings' => array(
                    'theme'  => 'shadowfox',
                     'mode'   => 'htmlmixed',
                  ),
                  'default' =>'<img src="https://aj0.cn/wp-content/uploads/2022/02/index.jpg" alt="Yazarı ödüllendirin" title="Yazarı ödüllendirin" width="306" height="487">',
                ),
    )
    ) );
        CSF::createSection( $prefix, array(
    'title' => 'Dizin Ayarı',
    'icon'  => 'fa fa-user-plus',
    'fields' => array(
                    array(
      'type'    => 'content',
    //   哥哥你倒卖可以但是留个群或者博客吧，不然用户就算买了不会用还不是找你，我做你的免费售后Q-Q交-流群：9173673-58
      'content' => 'Arkadaş hesabının birçok kullanımı vardır, 1. Dostça bağlantı sayfası olarak kullanılabilir. 2. Site navigasyonu yapabilirsiniz. 3. Sınıflandırılabilir',
    ),
    array(
      'id'       => 'opt-yrz-title',
      'type'     => 'group',
      'title'    => 'Dizin ayarları',
      'subtitle' => 'Lütfen -> Sayfalar -> Yeni Sayfa -> Arkadaş Hesabı Şablonu -> bölümüne gidin ve gezinme çubuğuna ekleyin',
      'fields'   => array(
        array(
          'id'    => 'opt-yrz-box',
          'type'  => 'text',
          'title' => 'Dizin Kategorisi',
             ),
                array(
                  'id'     => 'opt-yrz-box-box',
                  'type'   => 'group',
                  'title'  => 'Dizin',
                                  'fields' => array(
                                                array(
                                                  'id'    => 'opt-yrz-box-box-title',
                                                  'type'  => 'text',
                                                  'title' => 'web sitesi adı',
                                                ),
                                                array(
                                                  'id'    => 'opt-yrz-box-box-jianjie',
                                                  'type'  => 'text',
                                                  'title' => 'Web Sitesi Tanıtımı',
                                                ),
                                                array(
                                                  'id'    => 'opt-yrz-box-box-url',
                                                  'type'  => 'text',
                                                  'title' => 'Link',
                                                ),
                                                array(
                                    		    'id'    => 'opt-yrz-box-box-img',
                                    		    'type'  => 'upload',
                                    			'title' => 'haritanın adresi',
                                    			'default' => '',
                                    		    	),
                                  )
                ),
      ),
      'default' => array(

        // top level defaults
        array(
          'opt-text' => 'Top Level 1',

          // sub level 1 defaults
          'opt-group-5-sublevel-1' => array(
            array(
              'opt-text' => 'Sub Level 1',
            ),
          ),
        ),
      )
    ),
    )
    ) );
        CSF::createSection( $prefix, array(
    'title' => 'SEO ayarları',
    'icon'  => 'fa fa-wpexplorer',
    'fields' => array(
       			array(
				'id'    => 'zero-footer-wzgjc',
				'type'  => 'text',
				'title' => 'web sitesi anahtar kelimeleri',
				'default' => 'teknik blog, kaynak ağı, kişisel blog sitesi',
			), 
       			array(
				'id'    => 'zero-footer-wzms',
				'type'  => 'text',
				'title' => 'web sitesi açıklaması',
				'default' => 'Teknik eğitimleri ve ağ kaynaklarını düzenli olarak paylaşın',
			), 
     array(
      'id'    => 'rp-article-og-switch',
      'type'  => 'switcher',
      'title' => 'Makale sayfası, OG (açık grafik) protokolünün yeni sürümünü açar',
       'default' => true,
       'subtitle' => 'SEO için elverişlidir, sosyal medyada, haberlerde vb. Bulunması ve dahil edilmesi daha kolaydır ve bağlantı resmi başlığı ve makalenin açıklaması standartlaştırılmıştır.',
         ),
    )
    ) );
// 
CSF::createSection( $prefix, array(
  'title'  => 'Küçük resim ayarları',
  'icon'   => 'fas fa-image',
  'fields' => array(
        		 array(
      'id'      => 'rp-page-tesetu-sw',
      'type'    => 'radio',
      'title'   => 'Küçük resim kırpma yöntemi',
      'inline'  => 'opt-index-xbanner',
      'subtitle' => 'Orijinal görüntü yüksek çözünürlüklü ve güvenlidir ve phpnin görüntüyü kırpması yükleme hızını artıracaktır',
      'options' => array(
         'tesetu1' => 'Varsayılan orijinal resim',
        'tesetu2' => 'php kırpma',
      ),
      'default' => 'tesetu1',
    ),
     array(
      'id'    => 'rp-timthumb-wailian-switch',
      'type'  => 'switcher',
      'title' => 'PHP kırpma, harici bağlantı görüntülerini destekler',
      'label' => '开关',
       'default' => false,
       'subtitle' => '（Timthumbun harici bağlantıları desteklemesine izin verilip verilmeyeceği, etkinleştirilirse, aşağıdaki Timthumb harici bağlantı etki alanı adını ayarlamanız gerekir, aksi takdirde harici bağlantı küçük resmi görüntülenmez.）',
         ),
    array(
				'id'    => 'rp-timthumb-bai',
				'type'  => 'text',
				'title' => 'Alan beyaz listesi',
				'subtitle' => 'Lütfen harici link görselinin güvenliğini sağlayınız, herkesin herhangi bir görsel yükleyebileceği harici link kullanmayınız! Birden çok alan adı virgülle ayrılır ve örneğin alt alan adları için doğru olabilir：aj0.cn,read.aj0.cn,img.aj0.cn',
			), 
  )
) );
// 
     CSF::createSection( $prefix, array(
    'title' => 'makale sayfası',
    'icon'  => 'fa fa-files-o',
    'fields' => array(
 array(
      'type'    => 'notice',
      'style'   => 'info',
      'content' => 'Makalenin sonu UI bileşenleri',
    ),
       array(
      'id'    => 'zero-footer-grxx',
      'type'  => 'switcher',
      'title' => 'alttaki kişisel bilgiler',
      'label' => '',
       'subtitle' => '<img src="'.get_template_directory_uri().'/images/zujian/dbgrxx.png" alt="img-1">',
       'default' => true,
    ),
           array(
      'id'    => 'zero-footer-wzdata',
      'type'  => 'switcher',
      'title' => 'alt son değiştirilme zamanı',
      'label' => '',
       'subtitle' => '<img src="'.get_template_directory_uri().'/images/zujian/dbwzdata.png" alt="img-1">',
       'default' => true,
    ),
           array(
      'id'    => 'zero-footer-dianzan',
      'type'  => 'switcher',
      'title' => 'alttaki gibi',
      'label' => '',
       'subtitle' => '<img src="'.get_template_directory_uri().'/images/zujian/dbdianzan.png" alt="img-1">',
       'default' => true,
    ),
         array(
      'id'    => 'zero-footer-dbxguantuijian',
      'type'  => 'switcher',
      'title' => 'Alt ile ilgili öneri',
      'label' => '',
       'subtitle' => '<img src="'.get_template_directory_uri().'/images/zujian/xgtj.svg" alt="img-1" style="width: 300px;">',
       'default' => true,
    ),
         array(
      'id'    => 'zero-footer-plk',
      'type'  => 'switcher',
      'title' => 'Makale yorum kutusu',
      'label' => 'Varsayılan olarak açık',
       'default' => true,
    ),
    array(
      'id'    => 'zero-footer-article-author',
      'type'  => 'switcher',
      'title' => 'Makale başlığının altındaki yazar adı kutusu',
      'label' => 'Varsayılan olarak kapalı',
       'default' => true,
       	'subtitle' => 'Yazar UI bileşeni makalenin sonuna eklendiğinden, bazı insanlar üzerinde yazarın adının bulunmasının rahatlığını sevmezler.',
    ),
    )
    ) );
    CSF::createSection( $prefix, array(
    'title' => 'SMTP ayarları',
    'icon'  => 'fa fa-envelope-o',
    'fields' => array(
       			array(
				'id'    => 'zero-smtp-fwqdz',
				'type'  => 'text',
				'title' => 'SMTP sunucusu',
				'subtitle' => 'Örnek:smtp.163.com',
			), 
       			array(
				'id'    => 'zero-smtp-dk',
				'type'  => 'text',
				'title' => 'SMTP bağlantı noktası',
				'subtitle' => 'QQ posta kutusu: 465. Netease posta kutusu: 465/994',
				'default' => '465',
			), 
       			array(
				'id'    => 'zero-smtp-ssl',
				'type'  => 'text',
				'title' => 'şifreleme',
				'subtitle' => 'Genellikle varsayılan:ssl',
				'default' => 'ssl',
			), 
       			array(
				'id'    => 'zero-smtp-fjyx',
				'type'  => 'text',
				'title' => 'E-posta',
			), 
       			array(
				'id'    => 'zero-smtp-ps',
				'type'  => 'text',
				'title' => 'Yetkilendirme şifresi sıfır olmayan zaman şifresi',
          'attributes'  => array(
                'type'      => 'password',
                'autocomplete' => 'off',
            ),
			), 
    )
    ) );
CSF::createSection( $prefix, array(
		'id'    => 'zero_w',
		'title' => 'Genişletilmiş işlev',
		'icon'  => 'fa fa-plus-circle',
		
	) );
CSF::createSection( $prefix, array(
		'title'  => 'Bağlantılar',
		'icon'  => 'fa fa-sitemap',
		'fields' => array(
		    array(
      'id'    => 'zero-footer-youqinglink',
      'type'  => 'switcher',
      'title' => 'Alt dostu bağlantı etkinleştirme işlevi',
      'label' => 'Varsayılan olarak alt bağlantıları aç',
       'default' => false,
        ),
        		    array(
      'id'    => 'zero-footer-youqinglink-ico',
      'type'  => 'switcher',
      'title' => 'Kolay bağlantının, kaynak sitenin ico simgesini otomatik olarak alacak şekilde etkinleştirilip etkinleştirilmediği',
      'label' => 'Varsayılan olarak kapalı',
       'subtitle' => 'Bir dezavantajı var.Diğerleri çok yavaş duruyorsa buraya da erişim çok yavaş.Ayarlarsanız httpsyi etkilemez.',
       'default' => true,
        ),
            array(
      'type'    => 'content',
    //   哥哥你倒卖可以但是留个群或者博客吧，不然用户就算买了不会用还不是找你，我做你的免费售后Q-Q交-流群：9173673-58
      'content' => 'Temanın üç yerleşik kolay bağlantı görüntüleme yöntemi vardır <hr>1. Kenar Çubuğu -> Görünüm -> Pencere Öğeleri -> Arkadaşlık Zinciri Pencere Öğesi Görünümü.<hr>2. Bağımsız sayfa modu: kenar çubuğu -> sayfa ——>Yeni——> Sağ alt köşe——>Arkadaşlık bağlantısı ekranı.<hr>3. Web sitesinin alt kısmı——>Üstten açın',
    ),
	)
	) );
        CSF::createSection( $prefix, array(
    'parent'      => 'zero_w',
    'title' => 'Tema sözde orijinal',
    'description' => 'Arama motorları, şablon homojenliğini analiz eden ve yargılayan bir algoritmaya sahiptir. Yani aynı şablon seti, çok fazla insan aynı şablonu kullanıyor, örümcekler uyuşuk ve hareket edemeyecek kadar tembel. <br/>Yani sözde orijinal teması doğdu<br/>Yalnızca 26 İngilizce harf ve İngilizce \'_-\' ve sayı girebileceğinizi ve sayılarla başlayamayacağınızı unutmayın QQ değişim grubu: 91736-7358',
    'fields' => array(
		array(
      'id'    => 'zero-body-tzhkg',
      'type'  => 'switcher',
      'title' => 'Şablon anti-homojenizasyon işlevini etkinleştir',
       'subtitle' => 'yeşil açık',
       'default' => false,
            ),
        array(
      'id'    => 'opt-body-tzh1',
      'type'  => 'text',
      'title' => 'Lütfen web sitesi adının baş harflerini girin',
      'subtitle' => '8 harf ile istediğiniz gibi girebilirsiniz.',
      'placeholder' => 'örnek：qzdy'
      
    ),
        array(
      'id'    => 'opt-body-tzh2',
      'type'  => 'text',
      'title' => 'Lütfen özel bir stil sınıfı adı girin',
      'subtitle' => 'Her grup arasındaki boşluk 4 grubu ayırmak için yeterlidir',
      'placeholder' => 'örnek：rzdy_css qzdy-2 qzdy  qzdyqzdy...'
    ),
    )
    ) );
CSF::createSection( $prefix, array(
    'parent'=> 'zero_w',
    'title' => 'Sunucu sosu arayüzü',
    'description' => 'Sunucu sosu, site yorumları için bir WeChat push mesajıdır.Sunucunun tema ile ilgisi yoktur, sadece böyle bir arayüz sağlar.Kullanılıp kullanılmaması size bağlıdır.Sunucu sosu maliyetinin yüksek olması nedeniyle, kullanılması tavsiye edilmez.',
    'fields' => array(
         		array(
      'id'    => 'zero-htai-wxts',
      'type'  => 'switcher',
      'title' => 'Sunucu sosunu aç',
       'subtitle' => 'yeşil açık',
       'default' => false,
            ),
						array(
				'id'    => 'zero-footer-serverjiang',
				'type'  => 'text',
				'title' => 'Sunucu sosu arayüzünü aç',
'subtitle' => '<p>Aç<a rel="external nofollow" target="_blank" href="https://sct.ftqq.com/upgrade?fr=sc" aria-label="sunucu sosu( yeni bir sekmede açılır)">sunucu sosu</a>nun resmi web sitesi girişi ve SendKeyi alın</p>',
				 'default' =>'',
			),
    )
    ) );
    // 二级二级二级二级二级二级二级二级v
CSF::createSection( $prefix, array(
    'title' => 'alt ayarlar',
      'icon'  => 'fa fa-sort-amount-desc',
    'fields' => array(
				array(
                  'id'       => 'opt-code-dibuzdyhtml',
                  'type'     => 'code_editor',
                  'title'    => '<strong>HTML Ekle&lt;br></strong>',
                  'subtitle' => 'Kendi html stillerinizi ekleyebilirsiniz',
                  'settings' => array(
                    'theme'  => 'shadowfox',
                     'mode'   => 'htmlmixed',
                  ),
                  'default' =>'<a href="https://aj0.cn/youren">Dizin</a> | <a href="https://aj0.cn/guanyu">hakkında</a> | <a href="https://aj0.cn/guanyu">İletişim</a> | <a href="https://gitee.com/MUCEO/qzdy">Lütfen ayarların alt kısmından değiştirin</a>',
                ),
                array(
                  'id'       => 'opt-code-dibutjs',
                  'type'     => 'code_editor',
                  'title'    => 'google analytics gibi alt istatistikler',
                  'subtitle' => '<strong>JS için</strong>Not Desteği',
                  'settings' => array(
                    'theme'  => 'dracula',
                    'mode'   => 'javascript',
                                     ),
                    ),
              	array(
				'id'    => 'zero-footer-dibubq',
				'type'  => 'textarea',
				'title' => 'alt özel metin',
				'subtitle' => 'altta özel metin vb.',
			),
    )
    ) );
// Field: backup
//Q-Q交-流群：9173673-58
CSF::createSection( $prefix, array(
  'title'       => 'Yedekle Ve İçeri Aktar',
  'icon'        => 'fa fa-fax',
  'fields'      => array(

    array(
      'type' => 'backup',
    ),
  )
) );
CSF::createSection( $prefix, array(
    'title' => 'hakkında',
    'icon'  => 'fas fa-upload',
    'fields' => array(
    array(
      'type'    => 'content',
    //   哥哥你倒卖可以但是留个群或者博客吧，不然用户就算买了不会用还不是找你，我做你的免费售后Q-Q交-流群：9173673-58
      'content' => 'Qzdy teması basit ve aşırı<hr>Hakkında: geliştirme kolay değil, lütfen bir telif hakkı bırakın, QQ değişim grubu: 917367358 (tema değişimi, güncelleme önerileri)<hr>Tema Qzdy v4.9.3 | <span class="layui -badge"><a href="https://aj0.cn/?p=51" style="color: #fff;" target="_blank">Tema açıklaması</a></span > | <span class="layui-badge layui-bg-black"><a href="https://gitee.com/MUCEO/qzdy" style="color: #fff;" target="_blank">kaynak Gitee</a ></span><hr class="layui-border-orange">Mevcut sürüm v4.9.3: <span class="layui-badge layui-bg-blue"><a href="https:/ /gitee.com /MUCEO/qzdy" style="color: #fff;" target="_blank">En son sürümün güncellenmiş adresi</a></span>',
    ),
          array(
        'type'    => 'subheading',
        'content' => 'güncelleme kaynağı',
      ),
          array(
        'id'          => 'qzdy_update_source',
        'type'        => 'image_select',
        'title' => 'tema güncelleme kaynağı',
        'options'     => array(
          'github'  => get_template_directory_uri().'/images/gxy/github.png',
          'qzdy'  => get_template_directory_uri().'/images/gxy/qzdy.png',
        ),
        'desc' => 'Yerel bir sunucu kullanıyorsanız, lütfen tema güncelleme kaynağınız olarak AJ0.CN resmi kaynağını kullanın.',
        'default'     => 'github'
      ),
    )
    ) );
    } ?>