<?php if ( ! defined( 'ABSPATH' )  ) { die; } // Cannot access directly.

//
// Metabox of the PAGE
// Set a unique slug-like ID
// Q-Q交-流群：9173673-58
// 作者博客：https://www.aj0.cn/
$prefix_post_opts = '_prefix_post_options';

//
// Create a metabox
//
CSF::createMetabox( $prefix_post_opts, array(
  'title'        => 'Özel SEO',
  'post_type'    => 'post',
  'data_type' => 'unserialize',
  'show_restore' => true,
) );

//
// Create a section
//
CSF::createSection( $prefix_post_opts, array(
  'fields' => array(

    //
    // A text field
    //
          array(
      'id'    => '_zero-wz-autoMenu-ml-kg',
      'type'  => 'switcher',
      'title' => 'Başlık listesini aç',
      'label' => '',
        'subtitle' => 'Editörün içerik başlığını seçmelisiniz/h2',
       'default' => false,
    ),
    array(
      'id'    => 'opt-textseoms',
      'type'  => 'text',
      'title' => 'Özel açıklama, "içeriğin" ilk 500 karakterini açıklama olarak kesmek için boş bırakın',
    ),

    array(
      'id'    => 'opt-textseogjc',
      'type'  => 'text',
      'title' => 'Özel anahtar kelime, anahtar kelime olarak "etiket" kullanmak için boş bırakın',
    ),
    array(
      'id'    => 'opt-wz-textbanquan',
      'type'  => 'text',
      'title' => 'özel telif hakkı',
      'subtitle' => 'Boş bırakın ve varsayılan: Aksi belirtilmedikçe, bu blogdaki tüm makaleler blogger tarafından orijinaldir。',
    ),
  )
) );
