<?php

add_action('init', 'ugp_textdomain');
function ugp_textdomain() {
	load_plugin_textdomain('ugp-domain', false, 'user-generate-password');
}
add_action( 'register_form', 'ugp_show_extra_register_fields' );
function ugp_show_extra_register_fields(){
	?>
	<p>
	<label for="password"><?php _e( 'Şifre (8 basamaktan fazla)', 'ugp-domain' );?><br/>
	<input id="password" class="input" type="password" tabindex="30" size="25" value="" name="password" />
	</label>
	</p>
	<p>
	<label for="repeat_password"><?php _e( 'Şifreyi tekrar girin', 'ugp-domain' );?><br/>
	<input id="repeat_password" class="input" type="password" tabindex="40" size="25" value="" name="repeat_password" />
	</label>
	</p>
	<p>
	<label for="are_you_human" style="font-size:14px"><?php _e( 'Üzgünüz, bot önlemek için lütfen bu sitenin adını girin：<b>'.get_bloginfo('name').'</b>' , 'ugp-domain' ); ?><br/>
	<input id="are_you_human" class="input" type="text" tabindex="40" size="25" value="" name="are_you_human" />
	</label>
	</p>
	<?php
}
/*
 * Check the form for errors
 */
add_action( 'register_post', 'ugp_check_extra_register_fields', 10, 3 );
function ugp_check_extra_register_fields($login, $email, $errors) {
	if ( $_POST['password'] !== $_POST['repeat_password'] ) {
		$errors->add( 'passwords_not_matched', __("<strong>Hata</strong>: şifre boş olamaz", 'ugp-domain' ) );
	}
	if ( strlen( $_POST['password'] ) < 8 ) {
		$errors->add( 'password_too_short', __("<strong>hata</strong>:  Şifre en az sekiz karakter uzunluğunda olmalıdır ", 'ugp-domain' ) );
	}
	if ( $_POST['are_you_human'] !== get_bloginfo( 'name' ) ) {
		$errors->add( 'not_human', __("<strong>hata</strong>: Lütfen site adını doğru giriniz.", 'ugp-domain' ) );
	}
}

/*
 * Storing WordPress user-selected password into database on registration
 */

add_action( 'user_register', 'ugp_register_extra_fields', 100 );
function ugp_register_extra_fields( $user_id ){
	$userdata = array();
	
	$userdata['ID'] = $user_id;
	if ( $_POST['password'] !== '' ) {
		$userdata['user_pass'] = $_POST['password'];
	}
	$new_user_id = wp_update_user( $userdata );
}

/*
 * Editing WordPress registration confirmation message
 */

add_filter( 'gettext', 'ugp_edit_password_email_text',20, 3 );
function ugp_edit_password_email_text ( $translated_text, $untranslated_text, $domain ) {
	if(in_array($GLOBALS['pagenow'], array('wp-login.php'))){
		if ( $untranslated_text == 'Şifre size e-posta ile gönderilecek.' ) {
			$translated_text = __( ' Şifre alanını boş bırakırsanız sizin için bir şifre alanı oluşturulacaktır. Şifre en az sekiz karakter uzunluğunda olmalıdır.', 'ugp-domain' );
		}
		if( $untranslated_text == ' Kayıt tamamlandı, lütfen e-postanızı kontrol edin.' ) {
			$translated_text = __( 'Kayıt tamamlandı. Lütfen giriş yapın veya e-postanızı kontrol edin。', 'ugp-domain' );
		}
	}
	return $translated_text;
}
?>