(function() {
    tinymce.create('tinymce.plugins.success', {
        init : function(ed, url) {
            ed.addButton('success', {
                title : 'yeşil arka plan çubuğu',
                image : url+'/images/success.png',
                onclick : function() {
                     ed.selection.setContent('[success]' + ed.selection.getContent() + '[/success]');
                }
            });
        },
        createControl : function(n, cm) {
            return null;
        },
    });
    tinymce.PluginManager.add('success', tinymce.plugins.success);
    tinymce.create('tinymce.plugins.info', {
        init : function(ed, url) {
            ed.addButton('info', {
                title : 'mavi arka plan çubuğu',
                image : url+'/images/info.png',
                onclick : function() {
                     ed.selection.setContent('[info]' + ed.selection.getContent() + '[/info]');
                }
            });
        },
        createControl : function(n, cm) {
            return null;
        },
    });
    tinymce.PluginManager.add('info', tinymce.plugins.info);
    tinymce.create('tinymce.plugins.warning', {
        init : function(ed, url) {
            ed.addButton('warning', {
                title : 'sarı arka plan çubuğu',
                image : url+'/images/warning.png',
                onclick : function() {
                     ed.selection.setContent('[warning]' + ed.selection.getContent() + '[/warning]');
                }
            });
        },
        createControl : function(n, cm) {
            return null;
        },
    });
    tinymce.PluginManager.add('warning', tinymce.plugins.warning);
    tinymce.create('tinymce.plugins.danger', {
        init : function(ed, url) {
            ed.addButton('danger', {
                title : 'kırmızı arka plan çubuğu',
                image : url+'/images/danger.png',
                onclick : function() {
                     ed.selection.setContent('[danger]' + ed.selection.getContent() + '[/danger]');
                }
            });
        },
        createControl : function(n, cm) {
            return null;
        },
    });
    tinymce.PluginManager.add('danger', tinymce.plugins.danger);     
    tinymce.create('tinymce.plugins.successbox', {
        init : function(ed, url) {
            ed.addButton('successbox', {
                title : 'yeşil panel',
                image : url+'/images/successbox.png',
                onclick : function() {
                     ed.selection.setContent('[successbox title="başlık içeriği"]' + ed.selection.getContent() + '[/successbox]');
                }
            });
        },
        createControl : function(n, cm) {
            return null;
        },
    });
    tinymce.PluginManager.add('successbox', tinymce.plugins.successbox);
    tinymce.create('tinymce.plugins.infoboxs', {
        init : function(ed, url) {
            ed.addButton('infoboxs', {
                title : 'mavi panel',
                image : url+'/images/infobox.png',
                onclick : function() {
                     ed.selection.setContent('[infobox title="başlık içeriği"]' + ed.selection.getContent() + '[/infobox]');
                }
            });
        },
        createControl : function(n, cm) {
            return null;
        },
    });
    tinymce.PluginManager.add('infoboxs', tinymce.plugins.infoboxs);
    tinymce.create('tinymce.plugins.warningbox', {
        init : function(ed, url) {
            ed.addButton('warningbox', {
                title : 'sarı panel',
                image : url+'/images/warningbox.png',
                onclick : function() {
                     ed.selection.setContent('[warningbox title="başlık içeriği"]' + ed.selection.getContent() + '[/warningbox]');
                }
            });
        },
        createControl : function(n, cm) {
            return null;
        },
    });
    tinymce.PluginManager.add('warningbox', tinymce.plugins.warningbox);
    tinymce.create('tinymce.plugins.dangerbox', {
        init : function(ed, url) {
            ed.addButton('dangerbox', {
                title : 'kırmızı panel',
                image : url+'/images/dangerbox.png',
                onclick : function() {
                     ed.selection.setContent('[dangerbox title="başlık içeriği"]' + ed.selection.getContent() + '[/dangerbox]');
                }
            });
        },
        createControl : function(n, cm) {
            return null;
        },
    });
    tinymce.PluginManager.add('dangerbox', tinymce.plugins.dangerbox);        
    tinymce.create('tinymce.plugins.title', {
        init : function(ed, url) {
            ed.addButton('title', {
                title : 'içerik başlığı',
                image : url+'/images/title.png',
                onclick : function() {
                     ed.selection.setContent('[title]' + ed.selection.getContent() + '[/title]');
                }
            });
        },
        createControl : function(n, cm) {
            return null;
        },
    });
    tinymce.PluginManager.add('title', tinymce.plugins.title);
    tinymce.create('tinymce.plugins.accordion', {
        init : function(ed, url) {
            ed.addButton('accordion', {
                title : 'genişletmek ve sözleşme',
                image : url+'/images/accordion.png',
                onclick : function() {
                     ed.selection.setContent('[collapse title="başlık içeriği"]' + ed.selection.getContent() + '[/collapse]');
                }
            });
        },
        createControl : function(n, cm) {
            return null;
        },
    });
    tinymce.PluginManager.add('accordion', tinymce.plugins.accordion);
    tinymce.create('tinymce.plugins.hide', {
        init : function(ed, url) {
            ed.addButton('hide', {
                title : 'Görmek için yanıtla',
                image : url+'/images/hide.png',
                onclick : function() {
                     ed.selection.setContent('[hide reply_to_this="true"]' + ed.selection.getContent() + '[/hide]');
                }
            });
        },
        createControl : function(n, cm) {
            return null;
        },
    });
    tinymce.PluginManager.add('hide', tinymce.plugins.hide);
    tinymce.create('tinymce.plugins.heimu', {
        init : function(ed, url) {
            ed.addButton('heimu', {
                title : 'Gölge',
                image : url+'/images/heimu.png',
                onclick : function() {
                     ed.selection.setContent('[heimu]' + ed.selection.getContent() + '[/heimu]');
                }
            });
        },
        createControl : function(n, cm) {
            return null;
        },
    });
    tinymce.PluginManager.add('heimu', tinymce.plugins.heimu);
    tinymce.create('tinymce.plugins.kbd', {
        init : function(ed, url) {
            ed.addButton('kbd', {
                title : 'klavye metni',
                image : url+'/images/kbd.png',
                onclick : function() {
                     ed.selection.setContent('[kbd]' + ed.selection.getContent() + '[/kbd]');
                }
            });
        },
        createControl : function(n, cm) {
            return null;
        },
    });
    tinymce.PluginManager.add('kbd', tinymce.plugins.kbd);
    tinymce.create('tinymce.plugins.mark', {
        init : function(ed, url) {
            ed.addButton('mark', {
                title : 'içerik işaretleme',
                image : url+'/images/mark.png',
                onclick : function() {
                     ed.selection.setContent('[mark]' + ed.selection.getContent() + '[/mark]');
                }
            });
        },
        createControl : function(n, cm) {
            return null;
        },
    });
    tinymce.PluginManager.add('mark', tinymce.plugins.mark);
    tinymce.create('tinymce.plugins.striped', {
        init : function(ed, url) {
            ed.addButton('striped', {
                title : 'ilerleme çubuğu',
                image : url+'/images/striped.png',
                onclick : function() {
                     ed.selection.setContent('[striped]' + ed.selection.getContent() + '[/striped]');
                }
            });
        },
        createControl : function(n, cm) {
            return null;
        },
    });
    tinymce.PluginManager.add('striped', tinymce.plugins.striped);
    tinymce.create('tinymce.plugins.bdbtn', {
        init : function(ed, url) {
            ed.addButton('bdbtn', {
                title : 'yerel indirme',
                image : url+'/images/bdbtn.png',
                onclick : function() {
                     ed.selection.setContent('[bdbtn]' + ed.selection.getContent() + '[/bdbtn]');
                }
            });
        },
        createControl : function(n, cm) {
            return null;
        },
    });
    tinymce.PluginManager.add('bdbtn', tinymce.plugins.bdbtn);
    tinymce.create('tinymce.plugins.ypbtn', {
        init : function(ed, url) {
            ed.addButton('ypbtn', {
                title : 'Özel İndirme',
                image : url+'/images/ypbtn.png',
                onclick : function() {
                     ed.selection.setContent('[ypbtn]' + ed.selection.getContent() + '[/ypbtn]');
                }
            });
        },
        createControl : function(n, cm) {
            return null;
        },
    });
    tinymce.PluginManager.add('ypbtn', tinymce.plugins.ypbtn);
    tinymce.create('tinymce.plugins.music', {
        init : function(ed, url) {
            ed.addButton('music', {
                title : 'NetEase Bulut Müziği',
                image : url+'/images/music.png',
                onclick : function() {
                     ed.selection.setContent('[music autoplay="0"]' + ed.selection.getContent() + '[/music]');
                }
            });
        },
        createControl : function(n, cm) {
            return null;
        },
    });
    tinymce.PluginManager.add('music', tinymce.plugins.music);
    tinymce.create('tinymce.plugins.youku', {
        init : function(ed, url) {
            ed.addButton('youku', {
                title : 'Youku videosu',
                image : url+'/images/youku.png',
                onclick : function() {
                     ed.selection.setContent('[youku]' + ed.selection.getContent() + '[/youku]');
                }
            });
        },
        createControl : function(n, cm) {
            return null;
        },
    });
    tinymce.PluginManager.add('youku', tinymce.plugins.youku);
    tinymce.create('tinymce.plugins.tudou', {
        init : function(ed, url) {
            ed.addButton('tudou', {
                title : 'Tudou Videous',
                image : url+'/images/tudou.png',
                onclick : function() {
                     ed.selection.setContent('[tudou code=""]' + ed.selection.getContent() + '[/tudou]');
                }
            });
        },
        createControl : function(n, cm) {
            return null;
        },
    });
    tinymce.PluginManager.add('tudou', tinymce.plugins.tudou);
    tinymce.create('tinymce.plugins.vqq', {
        init : function(ed, url) {
            ed.addButton('vqq', {
                title : 'Vqq Videosu',
                image : url+'/images/vqq.png',
                onclick : function() {
                     ed.selection.setContent('[vqq auto="0"]' + ed.selection.getContent() + '[/vqq]');
                }
            });
        },
        createControl : function(n, cm) {
            return null;
        },
    });
    tinymce.PluginManager.add('vqq', tinymce.plugins.vqq);
    tinymce.create('tinymce.plugins.bilibili', {
        init : function(ed, url) {
            ed.addButton('bilibili', {
                title : 'Bilibili Videosu',
                image : url+'/images/bilibili.png',
                onclick : function() {
                     ed.selection.setContent('[bilibili danmaku="1" page="1"]' + ed.selection.getContent() + '[/bilibili]');
                }
            });
        },
        createControl : function(n, cm) {
            return null;
        },
    });
    tinymce.PluginManager.add('bilibili', tinymce.plugins.bilibili);
    tinymce.create('tinymce.plugins.youtube', {
        init : function(ed, url) {
            ed.addButton('youtube', {
                title : 'YouTube',
                image : url+'/images/youtube.png',
                onclick : function() {
                     ed.selection.setContent('[youtube]' + ed.selection.getContent() + '[/youtube]');
                }
            });
        },
        createControl : function(n, cm) {
            return null;
        },
    });
    tinymce.PluginManager.add('youtube', tinymce.plugins.youtube); 
        tinymce.create('tinymce.plugins.qzdypre', {
        init : function(ed, url) {
            ed.addButton('qzdypre', {
                title : 'siyah kod vurgusu',
                image : url+'/images/highlight.png',
                onclick : function() {
                     ed.selection.setContent('[qzdypre]' + ed.selection.getContent() + '[/qzdypre]');
                }
            });
        },
        createControl : function(n, cm) {
            return null;
        },
    });
    tinymce.PluginManager.add('qzdypre', tinymce.plugins.qzdypre); 
})();
