(function() {
	tinymce.PluginManager.add('begin_mce_button', function( editor, url ) {
		editor.addButton( 'begin_mce_button', {
			text: false,
			icon: 'editimage',
			title : 'kısa kod',
			type: 'menubutton',
			menu: [
					{
					text: 'içerik koruması',
					menu: [
						{
							text: 'şifre koruması',
							icon: 'lock',
							onclick: function() {
								selected = tinyMCE.activeEditor.selection.getContent();
								editor.insertContent('[secret key=parola]'+selected+'[/secret]');
							}
						},


						{
							text: 'Yorum kilidi',
							icon: 'bubble',
							onclick: function() {
								selected = tinyMCE.activeEditor.selection.getContent();
								editor.insertContent('[reply]'+selected+'[/reply]');
							}
						},

						{
							text: 'Gizli kilit',
							icon: 'user',
							onclick: function() {
								selected = tinyMCE.activeEditor.selection.getContent();
								editor.insertContent('[hide]'+selected+'[/hide]');
							}
						},


					]
				},

				{
					text: 'bağlantı düğmesi',
					menu: [
					    						{
							text: 'normal düğme',
							icon: 'newtab',
							onclick: function() {
								editor.insertContent('[link href=' + 'Bağlantı adresi] düğme adı[/link]');
							}
						},
					    
					    
					    
						{
							text: 'orta düğme',
							icon: 'nonbreaking',
							onclick: function() {
								editor.insertContent('[jzbut href=' + 'İndirme bağlantısı adresi] düğme adı[/jzbut]');
							}
						},

					]
				},

				{
					text: 'Kapsamlı işlev',
					menu: [



						{
							text: 'metin katlama',
							icon: 'pluscircle',
							onclick: function() {
		
								editor.insertContent('[collapse title="başlık içeriği"]' + '[/collapse]');
							
							}
						},



						{
							text: 'iframe etiketi',
							icon: 'template',
							onclick: function() {
								editor.insertContent('[iframe src="URL"' + ']');
							}
						},


						{
							text: 'MP4 videosu',
							icon: 'media',
							onclick: function() {
								editor.insertContent('[videos src=video adresi]');
							}
						},
						
	
					]
				},

				{
					text: 'renkli arka plan',
					menu: [
						{
							text: 'yeşil Kutu',
							icon: 'fill',
							onclick: function() {
								selected = tinyMCE.activeEditor.selection.getContent();
								editor.insertContent('[mark_a]'+selected+'[/mark_a]');
							}
						},

						{
							text: 'Mavi kutu',
							icon: 'fill',
							onclick: function() {
								selected = tinyMCE.activeEditor.selection.getContent();
								editor.insertContent('[mark_b]'+selected+'[/mark_b]');
							}
						},

						{
							text: 'Sarı Kutu',
							icon: 'fill',
							onclick: function() {
								selected = tinyMCE.activeEditor.selection.getContent();
								editor.insertContent('[mark_c]'+selected+'[/mark_c]');
							}
						},

						{
							text: 'kırmızı kutu',
							icon: 'fill',
							onclick: function() {
								selected = tinyMCE.activeEditor.selection.getContent();
								editor.insertContent('[mark_d]'+selected+'[/mark_d]');
							}
						},

					]
				}
			]
		});
	});
})();